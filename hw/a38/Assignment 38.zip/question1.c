// Recursive program to Display
//  Input:      5
//  Output: 5   *   4   *   3   *   2   *   1   *

#include<stdio.h>

void DisplayR(int iNo)
{

}

int main()
{
    int iValue = 0;

    printf("Enter Number : \n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}