// Accept Character check it's special symbol or not

#include<iostream>
using namespace std;

void Display(char ch)
{
    cout << 


}

int main()
{
    char cValue = '\0';
    bool bRet = false;

    cout << "Enter the Character : " << endl;
    cin >> cValue;

    Display(cValue);

    return 0;
}